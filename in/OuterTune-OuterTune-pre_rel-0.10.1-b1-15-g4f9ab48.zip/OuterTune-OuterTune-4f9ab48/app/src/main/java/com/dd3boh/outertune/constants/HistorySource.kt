package com.dd3boh.outertune.constants

enum class HistorySource {
    LOCAL, REMOTE
}