## material-color-utilities

Commit: c50b4106030b35449baf7ec71b74963deff072dd

Source: https://github.com/material-foundation/material-color-utilities

Path: /material-color-utilities

Notes:
- https://github.com/material-foundation/material-color-utilities/tree/main/java


## Gramophone Lyrics parser

Commit: 6d71d69fb036a91decc65ed362cde84a3468c2c6

Source: https://github.com/FoedusProgramme/Gramophone

Path: /app/src/main/java/org/akanework/gramophone/logic

Notes: 
- The lyrics parser has been modified to work with OuterTune (usually) where denoted


## TreeDocumentFile

Commit: 1d17c1928669610eb315310418c406d3bc7df981 

Source: https://android.googlesource.com/platform/frameworks/support/

path: \app\src\main\java\androidx\documentfile\provider
