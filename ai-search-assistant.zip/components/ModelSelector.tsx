import React, { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check, Zap, BrainCircuit } from 'lucide-react';
import { MODELS } from '../constants';
import { ModelOption } from '../types';

interface ModelSelectorProps {
  currentModelId: string;
  onModelChange: (modelId: string) => void;
  disabled?: boolean;
}

const ModelSelector: React.FC<ModelSelectorProps> = ({ currentModelId, onModelChange, disabled }) => {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const currentModel = MODELS.find(m => m.id === currentModelId) || MODELS[0];

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const getIcon = (id: string) => {
    if (id.includes('pro')) return <BrainCircuit className="w-4 h-4 text-purple-400" />;
    return <Zap className="w-4 h-4 text-yellow-400" />;
  };

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => !disabled && setIsOpen(!isOpen)}
        disabled={disabled}
        className={`flex items-center gap-2 px-3 py-2 rounded-lg text-lg font-medium text-zinc-200 hover:bg-zinc-800 transition-colors ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        <span>{currentModel.name}</span>
        <ChevronDown className={`w-4 h-4 text-zinc-500 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute top-full left-0 mt-2 w-[300px] bg-zinc-900 border border-zinc-700 rounded-xl shadow-xl z-50 overflow-hidden">
          <div className="p-1">
            {MODELS.map((model) => (
              <button
                key={model.id}
                onClick={() => {
                  onModelChange(model.id);
                  setIsOpen(false);
                }}
                className="flex items-start gap-3 w-full p-3 rounded-lg hover:bg-zinc-800 transition-colors text-left"
              >
                <div className="mt-0.5 p-2 rounded-md bg-zinc-950 border border-zinc-800">
                    {getIcon(model.id)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-zinc-200">{model.name}</span>
                    {currentModelId === model.id && (
                      <Check className="w-4 h-4 text-zinc-100" />
                    )}
                  </div>
                  <p className="text-xs text-zinc-500 mt-0.5">{model.description}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ModelSelector;
