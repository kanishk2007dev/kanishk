import React from 'react';
import ReactMarkdown from 'react-markdown';
import { User, Sparkles, Copy, Check, ExternalLink, Search, Globe, ChevronRight } from 'lucide-react';
import { Role, Message } from '../types';

interface MessageItemProps {
  message: Message;
}

const MessageItem: React.FC<MessageItemProps> = ({ message }) => {
  const isUser = message.role === Role.USER;
  const [copied, setCopied] = React.useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(message.text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className={`w-full text-zinc-100 py-6 ${isUser ? '' : 'bg-transparent'}`}>
      <div className="max-w-3xl mx-auto flex gap-4 lg:gap-6 px-4 md:px-0">
        <div className="flex-shrink-0 flex flex-col relative">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center shadow-sm ${isUser ? 'bg-zinc-800' : 'bg-blue-600/10 border border-blue-500/20'}`}>
            {isUser ? (
              <User className="w-4 h-4 text-zinc-300" />
            ) : (
              <Sparkles className="w-4 h-4 text-blue-400" />
            )}
          </div>
        </div>

        <div className="relative flex-1 overflow-hidden min-w-0">
          <div className="font-medium text-sm text-zinc-400 mb-1">
            {isUser ? 'You' : 'AI Assistant'}
          </div>
          
          {!isUser && (
            <>
               {/* Search Queries Section */}
                {message.searchQueries && message.searchQueries.length > 0 && (
                    <div className="mb-4">
                        <div className="flex items-center gap-2 text-xs font-medium text-zinc-500 mb-2 uppercase tracking-wider">
                            <Search className="w-3 h-3" />
                            Searching
                        </div>
                        <div className="flex flex-wrap gap-2 animate-fade-in">
                            {message.searchQueries.map((query, i) => (
                                <div key={i} className="flex items-center gap-1.5 text-xs text-zinc-300 bg-zinc-800/50 px-3 py-1.5 rounded-full border border-zinc-700/50 hover:bg-zinc-800 transition-colors cursor-default">
                                    <span>{query}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

              {/* Sources Section - Grid Layout */}
              {message.sources && message.sources.length > 0 && (
                <div className="mb-6 animate-fade-in">
                  <div className="flex items-center gap-2 text-xs font-medium text-zinc-500 mb-2 uppercase tracking-wider">
                    <Globe className="w-3 h-3" />
                    Sources
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                    {message.sources.map((source, index) => (
                      <a
                        key={index}
                        href={source.uri}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex flex-col justify-between p-3 rounded-xl bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 transition-all group/card h-20 relative overflow-hidden"
                      >
                        <div className="text-[10px] text-zinc-500 truncate mb-1 flex items-center gap-1.5">
                             {/* Favicon fallback handled safely */}
                            <div className="w-3.5 h-3.5 rounded-full bg-zinc-800 flex items-center justify-center overflow-hidden flex-shrink-0">
                                <img 
                                src={`https://www.google.com/s2/favicons?domain=${new URL(source.uri).hostname}&sz=32`} 
                                alt="" 
                                className="w-full h-full object-cover opacity-80"
                                onError={(e) => { (e.target as HTMLImageElement).style.opacity = '0'; }}
                                />
                            </div>
                            <span className="truncate opacity-80">{new URL(source.uri).hostname.replace(/^www\./, '')}</span>
                        </div>
                        <div className="text-xs font-medium text-zinc-300 leading-snug line-clamp-2 group-hover/card:text-blue-300 transition-colors">
                          {source.title}
                        </div>
                      </a>
                    ))}
                    {/* View more indicator if specific count logic was needed, omitted for now */}
                  </div>
                </div>
              )}
            </>
          )}

          <div className="prose prose-invert prose-sm md:prose-base prose-p:leading-relaxed prose-pre:bg-zinc-900 prose-pre:border prose-pre:border-zinc-800 prose-pre:rounded-xl max-w-none break-words">
            <ReactMarkdown
               components={{
                a: ({ node, ...props }) => (
                  <a {...props} className="text-blue-400 hover:text-blue-300 hover:underline decoration-blue-400/30 underline-offset-2 transition-colors" target="_blank" rel="noopener noreferrer">
                      {props.children}
                  </a>
                ),
                code({node, inline, className, children, ...props}: any) {
                  return !inline ? (
                     <div className="relative group/code my-5">
                        <div className="absolute right-3 top-3 opacity-0 group-hover/code:opacity-100 transition-opacity">
                            <span className="text-[10px] text-zinc-500 font-mono">Code</span>
                        </div>
                        <pre className="bg-zinc-900/50 p-4 rounded-xl overflow-x-auto border border-zinc-800/80 text-sm shadow-inner">
                            <code {...props} className={className}>
                                {children}
                            </code>
                        </pre>
                     </div>
                  ) : (
                    <code {...props} className="bg-zinc-800/80 px-1.5 py-0.5 rounded text-sm text-zinc-200 font-mono border border-zinc-700/50">
                      {children}
                    </code>
                  )
                }
               }}
            >
              {message.text}
            </ReactMarkdown>
          </div>

          {!isUser && !message.isError && message.text && (
            <div className="flex items-center gap-3 mt-4">
               <button 
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-2 py-1 rounded-md text-zinc-500 hover:bg-zinc-800 hover:text-zinc-300 transition-colors text-xs font-medium"
               >
                 {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                 {copied ? 'Copied' : 'Copy'}
               </button>
            </div>
          )}
           {message.isError && (
              <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg text-red-400 text-sm mt-3 flex items-center gap-2">
                  <span>⚠️</span> Error generating response. Please try again.
              </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MessageItem;