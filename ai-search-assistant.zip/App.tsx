import React, { useState, useEffect, useRef } from 'react';
import { Menu, Search, Sparkles } from 'lucide-react';
import { Chat } from '@google/genai';
import { v4 as uuidv4 } from 'uuid';

import Sidebar from './components/Sidebar';
import MessageItem from './components/MessageItem';
import InputArea from './components/InputArea';
import ModelSelector from './components/ModelSelector';
import { createChatSession, sendMessageStream } from './services/geminiService';
import { ChatSession, Message, Role } from './types';
import { DEFAULT_MODEL_ID } from './constants';

const generateId = () => Math.random().toString(36).substring(2, 15);

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [currentSessionId, setCurrentSessionId] = useState<string | null>(null);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [currentModelId, setCurrentModelId] = useState(DEFAULT_MODEL_ID);

  const chatInstanceRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const stopFlagRef = useRef(false);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [sessions, currentSessionId, isLoading]);

  const initChat = (modelId: string) => {
    try {
        chatInstanceRef.current = createChatSession(modelId);
    } catch (e) {
        console.error("Failed to init chat", e);
    }
  };

  const handleSelectSession = (id: string) => {
    setCurrentSessionId(id);
    const session = sessions.find(s => s.id === id);
    if (session) {
        initChat(session.modelId); 
        setCurrentModelId(session.modelId);
    }
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  };

  const handleNewChat = () => {
    const newSession: ChatSession = {
      id: generateId(),
      title: 'New Search',
      messages: [],
      modelId: currentModelId,
      createdAt: Date.now(),
    };
    
    setSessions(prev => [newSession, ...prev]);
    setCurrentSessionId(newSession.id);
    initChat(currentModelId);
    if (window.innerWidth < 768) {
      setSidebarOpen(false);
    }
  };

  const handleDeleteSession = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setSessions(prev => prev.filter(s => s.id !== id));
    if (currentSessionId === id) {
      setCurrentSessionId(null);
      chatInstanceRef.current = null;
    }
  };

  const handleModelChange = (id: string) => {
    setCurrentModelId(id);
    const currentSession = sessions.find(s => s.id === currentSessionId);
    if (currentSession && currentSession.messages.length === 0) {
        setSessions(prev => prev.map(s => s.id === currentSessionId ? { ...s, modelId: id } : s));
        initChat(id);
    } else {
        handleNewChat();
    }
  };

  const handleStop = () => {
    stopFlagRef.current = true;
    setIsLoading(false);
  };

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    stopFlagRef.current = false;
    let activeSessionId = currentSessionId;
    if (!activeSessionId) {
      const newSession: ChatSession = {
        id: generateId(),
        title: input.trim().slice(0, 30),
        messages: [],
        modelId: currentModelId,
        createdAt: Date.now(),
      };
      setSessions(prev => [newSession, ...prev]);
      activeSessionId = newSession.id;
      setCurrentSessionId(newSession.id);
      initChat(currentModelId);
    }

    if (!chatInstanceRef.current) {
        initChat(currentModelId);
    }

    const userMessage: Message = {
      id: generateId(),
      role: Role.USER,
      text: input.trim(),
      timestamp: Date.now(),
    };

    setSessions(prev => prev.map(session => {
      if (session.id === activeSessionId) {
        const title = session.messages.length === 0 ? userMessage.text.slice(0, 30) : session.title;
        return {
          ...session,
          title,
          messages: [...session.messages, userMessage]
        };
      }
      return session;
    }));

    setInput('');
    setIsLoading(true);

    const botMessageId = generateId();
    const botMessagePlaceholder: Message = {
      id: botMessageId,
      role: Role.MODEL,
      text: '', 
      timestamp: Date.now(),
    };

    setSessions(prev => prev.map(session => {
      if (session.id === activeSessionId) {
        return {
          ...session,
          messages: [...session.messages, botMessagePlaceholder]
        };
      }
      return session;
    }));

    try {
        if (!chatInstanceRef.current) throw new Error("Chat not initialized");

        await sendMessageStream(
          chatInstanceRef.current, 
          userMessage.text, 
          (chunkText, sources, searchQueries) => {
            if (stopFlagRef.current) return;
            
            setSessions(prev => prev.map(session => {
                if (session.id === activeSessionId) {
                  return {
                    ...session,
                    messages: session.messages.map(msg => 
                        msg.id === botMessageId ? { 
                            ...msg, 
                            text: chunkText, 
                            sources: sources,
                            searchQueries: searchQueries 
                        } : msg
                    )
                  };
                }
                return session;
              }));
        });
    } catch (error) {
        if (!stopFlagRef.current) {
            console.error("Error sending message:", error);
            setSessions(prev => prev.map(session => {
                if (session.id === activeSessionId) {
                  return {
                    ...session,
                    messages: session.messages.map(msg => 
                        msg.id === botMessageId ? { ...msg, text: "Sorry, I encountered an issue. Please ensure your API key is valid.", isError: true } : msg
                    )
                  };
                }
                return session;
              }));
        }
    } finally {
        setIsLoading(false);
    }
  };

  const currentSession = sessions.find(s => s.id === currentSessionId);
  
  useEffect(() => {
      if (sessions.length === 0 && !currentSessionId) {
          handleNewChat();
      }
      // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="flex h-screen bg-zinc-950 text-zinc-100 overflow-hidden font-sans selection:bg-blue-500/30 selection:text-blue-200">
      <Sidebar 
        isOpen={sidebarOpen}
        setIsOpen={setSidebarOpen}
        sessions={sessions}
        currentSessionId={currentSessionId}
        onSelectSession={handleSelectSession}
        onNewChat={handleNewChat}
        onDeleteSession={handleDeleteSession}
      />

      <div className="flex-1 flex flex-col h-full relative transition-all">
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-zinc-950/80 backdrop-blur z-10 sticky top-0 border-b border-zinc-800/50">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setSidebarOpen(true)}
              className="md:hidden p-2 text-zinc-400 hover:bg-zinc-800 rounded-lg transition-colors"
            >
              <Menu className="w-5 h-5" />
            </button>
            <ModelSelector 
                currentModelId={currentSession?.modelId || currentModelId} 
                onModelChange={handleModelChange}
                disabled={currentSession ? currentSession.messages.length > 0 : false}
            />
          </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-transparent">
          {currentSession && currentSession.messages.length > 0 ? (
            <div className="flex flex-col pb-4">
              {currentSession.messages.map((msg) => (
                <MessageItem key={msg.id} message={msg} />
              ))}
              <div ref={messagesEndRef} className="h-4" />
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-zinc-500 p-8 text-center animate-fade-in pb-32">
              <div className="w-16 h-16 bg-zinc-900 rounded-2xl flex items-center justify-center mb-6 border border-zinc-800 shadow-xl shadow-zinc-950/50">
                 <Sparkles className="w-8 h-8 text-blue-500" />
              </div>
              <h2 className="text-2xl md:text-3xl font-bold text-zinc-100 mb-3 tracking-tight">How can I help you today?</h2>
              <p className="max-w-md text-zinc-400 text-base leading-relaxed">
                  I can search the web, write code, analyze data, and help you learn something new.
              </p>
            </div>
          )}
        </div>

        <InputArea 
          input={input}
          setInput={setInput}
          onSend={handleSend}
          isLoading={isLoading}
          onStop={handleStop} 
        />
      </div>
    </div>
  );
}

export default App;