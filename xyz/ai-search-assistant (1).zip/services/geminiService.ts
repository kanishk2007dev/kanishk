import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { Message, Role, Source } from '../types';

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API_KEY environment variable is not set.");
  }
  return new GoogleGenAI({ apiKey });
};

export const createChatSession = (modelId: string) => {
  const ai = getClient();
  
  let actualModel = modelId;
  let thinkingBudget = 0;

  // Handle custom mapping for UI-specific "Thinking" model option
  if (modelId === 'gemini-2.5-flash-thinking') {
    actualModel = 'gemini-2.5-flash';
    thinkingBudget = 1024;
  }

  const config: any = {
    // Updated instruction to include image handling capabilities
    systemInstruction: `You are a knowledgeable AI search assistant. You provide accurate, up-to-date, and comprehensive answers. 
    
    1. **Search Grounding**: You ALWAYS use the Google Search tool to find information when answering questions about current events, facts, or specific knowledge. Integrate the information naturally.
    
    2. **Images**: If the user asks for images, pictures, or visual content:
       - Attempt to find and embed valid, public image URLs using Markdown syntax: ![description](url). 
       - Prefer stable sources like Wikimedia Commons or official generic placeholder images if specific ones aren't stable.
       - If you cannot find a direct image to embed, provide a Markdown link labeled "Click to view images of [Subject]" pointing to a Google Image Search URL (e.g., https://www.google.com/search?tbm=isch&q=Subject).
       - Do not make up URLs. If unsure, provide the search link.`,
    tools: [{ googleSearch: {} }] // Enable Search Grounding
  };

  if (thinkingBudget > 0) {
    config.thinkingConfig = { thinkingBudget };
  }

  return ai.chats.create({
    model: actualModel,
    config,
    history: []
  });
};

export const sendMessageStream = async (
  chat: Chat, 
  message: string, 
  onUpdate: (text: string, sources?: Source[], searchQueries?: string[]) => void
): Promise<string> => {
  let fullText = "";
  let collectedSources: Source[] = [];
  let collectedQueries: string[] = [];
  
  try {
    const resultStream = await chat.sendMessageStream({ message });
    
    for await (const chunk of resultStream) {
      const c = chunk as GenerateContentResponse;
      const text = c.text;
      const metadata = c.candidates?.[0]?.groundingMetadata;
      
      // Extract Search Queries
      if (metadata?.webSearchQueries) {
         metadata.webSearchQueries.forEach((q: string) => {
             if (!collectedQueries.includes(q)) {
                 collectedQueries.push(q);
             }
         });
      }

      // Check for grounding metadata in the chunk for Sources
      const groundingChunks = metadata?.groundingChunks;
      
      if (groundingChunks) {
        groundingChunks.forEach((chunk: any) => {
          if (chunk.web) {
            collectedSources.push({
              title: chunk.web.title || "Source",
              uri: chunk.web.uri
            });
          }
        });
        // Remove duplicates based on URI
        collectedSources = collectedSources.filter((v, i, a) => a.findIndex(t => (t.uri === v.uri)) === i);
      }

      if (text) {
        fullText += text;
      }
      
      // Pass text, sources, and queries back to the UI
      onUpdate(
          fullText, 
          collectedSources.length > 0 ? collectedSources : undefined,
          collectedQueries.length > 0 ? collectedQueries : undefined
      );
    }
  } catch (error) {
    console.error("Gemini Stream Error:", error);
    throw error;
  }

  return fullText;
};