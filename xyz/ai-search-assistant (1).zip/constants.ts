import { ModelOption } from './types';

export const MODELS: ModelOption[] = [
  {
    id: 'gemini-2.5-flash',
    name: 'Flash (Fast)',
    description: 'Quick answers for everyday tasks.'
  },
  {
    id: 'gemini-3-pro-preview',
    name: 'Pro (Smart)',
    description: 'Deep reasoning for complex queries.',
    isPro: true
  },
  {
    id: 'gemini-2.5-flash-thinking', // Fictional ID mapping to config usage in service
    name: 'Reasoning (Deep)',
    description: 'Enhanced logic and problem solving.'
  }
];

export const DEFAULT_MODEL_ID = 'gemini-2.5-flash';