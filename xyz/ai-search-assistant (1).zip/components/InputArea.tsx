import React, { useRef, useEffect } from 'react';
import { SendHorizontal, StopCircle, CornerDownLeft } from 'lucide-react';

interface InputAreaProps {
  input: string;
  setInput: (value: string) => void;
  onSend: () => void;
  isLoading: boolean;
  onStop: () => void;
}

const InputArea: React.FC<InputAreaProps> = ({ input, setInput, onSend, isLoading, onStop }) => {
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      onSend();
    }
  };

  return (
    <div className="w-full bg-zinc-950/80 backdrop-blur-sm border-t border-zinc-800/50 pt-4 pb-6 px-4 z-20">
      <div className="max-w-3xl mx-auto relative">
        <div className={`
            relative flex items-end w-full p-3 bg-zinc-900 rounded-2xl border transition-all shadow-sm
            ${isLoading ? 'border-zinc-700/50' : 'border-zinc-700 hover:border-zinc-600 focus-within:ring-1 focus-within:ring-blue-500/30 focus-within:border-blue-500/50'}
        `}>
          <textarea
            ref={textareaRef}
            rows={1}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Ask anything, or 'Show me images of...'"
            className="w-full max-h-[200px] py-2 pl-2 pr-12 bg-transparent text-zinc-100 placeholder-zinc-500 resize-none focus:outline-none scrollbar-hide leading-relaxed"
            disabled={isLoading}
          />
          
          <div className="absolute right-2 bottom-2">
            {isLoading ? (
               <button 
               onClick={onStop}
               className="p-2 rounded-lg bg-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-700 transition-all group"
               title="Stop generating"
             >
                <div className="relative w-5 h-5 flex items-center justify-center">
                    <StopCircle className="w-5 h-5" />
                </div>
             </button>
            ) : (
              <button
                onClick={onSend}
                disabled={!input.trim()}
                className={`p-2 rounded-xl transition-all duration-200 ${
                  input.trim() 
                    ? 'bg-blue-600 text-white hover:bg-blue-500 shadow-lg shadow-blue-900/20' 
                    : 'bg-zinc-800 text-zinc-600 cursor-not-allowed'
                }`}
              >
                {input.trim() ? <SendHorizontal className="w-4 h-4" /> : <CornerDownLeft className="w-4 h-4" />}
              </button>
            )}
          </div>
        </div>
        <div className="text-center mt-3">
            <p className="text-[10px] text-zinc-600 font-medium">
                AI Search can make mistakes. Please verify important information.
            </p>
        </div>
      </div>
    </div>
  );
};

export default InputArea;