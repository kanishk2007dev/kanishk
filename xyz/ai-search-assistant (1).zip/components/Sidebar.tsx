import React from 'react';
import { Plus, MessageSquare, Trash2, Settings, UserCircle } from 'lucide-react';
import { ChatSession } from '../types';

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
  sessions: ChatSession[];
  currentSessionId: string | null;
  onSelectSession: (id: string) => void;
  onNewChat: () => void;
  onDeleteSession: (id: string, e: React.MouseEvent) => void;
}

const Sidebar: React.FC<SidebarProps> = ({
  isOpen,
  setIsOpen,
  sessions,
  currentSessionId,
  onSelectSession,
  onNewChat,
  onDeleteSession
}) => {
  return (
    <>
      {/* Mobile Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-black/60 z-20 md:hidden backdrop-blur-sm"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar Container */}
      <div className={`
        fixed inset-y-0 left-0 z-30 w-[280px] bg-zinc-950 flex flex-col transition-transform duration-300 ease-in-out border-r border-zinc-800/50
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
        md:translate-x-0 md:static md:w-[280px] md:flex-shrink-0
      `}>
        <div className="p-4 flex-none">
          <button
            onClick={onNewChat}
            className="flex items-center gap-3 w-full px-4 py-3 rounded-full border border-zinc-700/50 bg-zinc-900/50 hover:bg-zinc-800 transition-all text-sm text-zinc-100 mb-2 shadow-sm group"
          >
            <Plus className="w-5 h-5 text-zinc-400 group-hover:text-white transition-colors" />
            <span className="font-medium">New Search</span>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto overflow-x-hidden px-3 scrollbar-hide">
          <div className="text-xs font-semibold text-zinc-500 mb-3 px-3 uppercase tracking-wider">History</div>
          
          <div className="flex flex-col gap-1">
            {sessions.map((session) => (
              <button
                key={session.id}
                onClick={() => onSelectSession(session.id)}
                className={`
                  group flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all text-left relative pr-9
                  ${session.id === currentSessionId 
                    ? 'bg-zinc-800/80 text-white shadow-sm' 
                    : 'text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200'
                  }
                `}
              >
                <MessageSquare className={`w-4 h-4 flex-shrink-0 ${session.id === currentSessionId ? 'text-blue-400' : 'text-zinc-600'}`} />
                <span className="truncate w-full block">
                  {session.title || 'New Search'}
                </span>
                
                {/* Delete Button */}
                <div 
                  className={`absolute right-2 top-1/2 -translate-y-1/2 p-1.5 rounded-md hover:bg-zinc-700 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity ${session.id === currentSessionId ? 'opacity-100 md:opacity-0 md:group-hover:opacity-100' : ''}`}
                  onClick={(e) => onDeleteSession(session.id, e)}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </div>
              </button>
            ))}
            
            {sessions.length === 0 && (
              <div className="px-3 py-8 text-zinc-600 text-sm text-center italic">
                No search history yet
              </div>
            )}
          </div>
        </div>

        <div className="p-4 border-t border-zinc-800/50">
           <div className="flex items-center gap-3 p-2 rounded-lg hover:bg-zinc-900/50 transition-colors cursor-pointer">
              <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-400">
                  <UserCircle className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                  <div className="text-sm font-medium text-zinc-200 truncate">Account</div>
                  <div className="text-xs text-zinc-500 truncate">Pro Plan</div>
              </div>
              <Settings className="w-4 h-4 text-zinc-600" />
           </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;